﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentSubfolders
{
    public class SubFolder
    {
        private string _name;
        private int _level;
            //for folder "T:\\BU - BUDGET AND FALL ECONOMIC STATEMENTS\\2021\\01 - Binder & Lock Up"
            //_level is 3
        private string _parentFolder;
        
        public Queue <SubFolder> subFolders = new Queue<SubFolder>();
        
        public SubFolder(string sfName, int sfLevel, string sfParentFolder)
        {
            _name = sfName;
            _level = sfLevel;
            _parentFolder = sfParentFolder;
            if (_level > Program.maxLevel )
            {
                Program.maxLevel = _level;//make sure we record the deepest subFolder 
            }
        }

        public string sfName
        {
            get { return _name; }
        }

        public int sfLevel
        {
            get { return _level; }
        }

        public string sfParentFolder
        {
            get { return _parentFolder; }
        }


        public SubFolder createDeeperFolder(string nlName, int nlLevel, string nlParentFolder)
        {
            SubFolder sf = new SubFolder(nlName, nlLevel, nlParentFolder);
            subFolders.Enqueue(sf);
            return sf;
        }
    }
}
