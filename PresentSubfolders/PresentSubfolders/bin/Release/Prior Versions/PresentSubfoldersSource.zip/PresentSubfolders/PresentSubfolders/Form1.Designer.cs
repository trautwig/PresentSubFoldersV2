﻿
namespace PresentSubfolders
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.doneLabel = new System.Windows.Forms.Label();
            this.excelFileLink = new System.Windows.Forms.LinkLabel();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.createExcel = new System.Windows.Forms.Button();
            this.selectLevelText = new System.Windows.Forms.Label();
            this.depthLevelText = new System.Windows.Forms.Label();
            this.depthLevelsToDisplay = new System.Windows.Forms.NumericUpDown();
            this.panel1 = new System.Windows.Forms.Panel();
            this.badResultsPanel = new System.Windows.Forms.Panel();
            this.badResultsLabel = new System.Windows.Forms.Label();
            this.levelDisplayGroup = new System.Windows.Forms.Panel();
            this.resultsDoneGroup = new System.Windows.Forms.Panel();
            this.workingLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.depthLevelsToDisplay)).BeginInit();
            this.panel1.SuspendLayout();
            this.badResultsPanel.SuspendLayout();
            this.levelDisplayGroup.SuspendLayout();
            this.resultsDoneGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // doneLabel
            // 
            this.doneLabel.AutoSize = true;
            this.doneLabel.Location = new System.Drawing.Point(3, 10);
            this.doneLabel.Name = "doneLabel";
            this.doneLabel.Size = new System.Drawing.Size(169, 13);
            this.doneLabel.TabIndex = 1;
            this.doneLabel.Text = "All done! Go check your Excel file:";
            // 
            // excelFileLink
            // 
            this.excelFileLink.AutoSize = true;
            this.excelFileLink.Location = new System.Drawing.Point(178, 10);
            this.excelFileLink.Name = "excelFileLink";
            this.excelFileLink.Size = new System.Drawing.Size(0, 13);
            this.excelFileLink.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 144);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Where are the folders to list?";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.SelectFolders);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(570, 68);
            this.label2.TabIndex = 3;
            this.label2.Text = resources.GetString("label2.Text");
            // 
            // createExcel
            // 
            this.createExcel.Location = new System.Drawing.Point(6, 39);
            this.createExcel.Name = "createExcel";
            this.createExcel.Size = new System.Drawing.Size(75, 23);
            this.createExcel.TabIndex = 7;
            this.createExcel.Text = "Create Excel File";
            this.createExcel.UseVisualStyleBackColor = true;
            this.createExcel.Click += new System.EventHandler(this.createExcel_Click);
            // 
            // selectLevelText
            // 
            this.selectLevelText.AutoSize = true;
            this.selectLevelText.Location = new System.Drawing.Point(3, 23);
            this.selectLevelText.Name = "selectLevelText";
            this.selectLevelText.Size = new System.Drawing.Size(185, 13);
            this.selectLevelText.TabIndex = 6;
            this.selectLevelText.Text = "Select the number of levels to display:";
            // 
            // depthLevelText
            // 
            this.depthLevelText.Location = new System.Drawing.Point(3, 0);
            this.depthLevelText.Name = "depthLevelText";
            this.depthLevelText.Size = new System.Drawing.Size(306, 18);
            this.depthLevelText.TabIndex = 4;
            this.depthLevelText.Text = "The folders found went to a depth of";
            // 
            // depthLevelsToDisplay
            // 
            this.depthLevelsToDisplay.Location = new System.Drawing.Point(194, 23);
            this.depthLevelsToDisplay.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.depthLevelsToDisplay.Name = "depthLevelsToDisplay";
            this.depthLevelsToDisplay.Size = new System.Drawing.Size(49, 20);
            this.depthLevelsToDisplay.TabIndex = 5;
            this.depthLevelsToDisplay.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.depthLevelsToDisplay.ValueChanged += new System.EventHandler(this.depthLevelsToDisplay_ValueChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.badResultsPanel);
            this.panel1.Controls.Add(this.levelDisplayGroup);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(19, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(577, 212);
            this.panel1.TabIndex = 0;
            // 
            // badResultsPanel
            // 
            this.badResultsPanel.Controls.Add(this.badResultsLabel);
            this.badResultsPanel.Location = new System.Drawing.Point(166, 125);
            this.badResultsPanel.Name = "badResultsPanel";
            this.badResultsPanel.Size = new System.Drawing.Size(358, 83);
            this.badResultsPanel.TabIndex = 6;
            // 
            // badResultsLabel
            // 
            this.badResultsLabel.Location = new System.Drawing.Point(16, 16);
            this.badResultsLabel.Name = "badResultsLabel";
            this.badResultsLabel.Size = new System.Drawing.Size(325, 48);
            this.badResultsLabel.TabIndex = 0;
            this.badResultsLabel.Text = "Failed to capture all folders. This may be the result of a network interruption. " +
    "Consdider trying again.";
            this.badResultsLabel.Click += new System.EventHandler(this.badResultsLabel_Click);
            // 
            // levelDisplayGroup
            // 
            this.levelDisplayGroup.Controls.Add(this.createExcel);
            this.levelDisplayGroup.Controls.Add(this.depthLevelText);
            this.levelDisplayGroup.Controls.Add(this.selectLevelText);
            this.levelDisplayGroup.Controls.Add(this.depthLevelsToDisplay);
            this.levelDisplayGroup.Location = new System.Drawing.Point(162, 127);
            this.levelDisplayGroup.Name = "levelDisplayGroup";
            this.levelDisplayGroup.Size = new System.Drawing.Size(391, 82);
            this.levelDisplayGroup.TabIndex = 5;
            // 
            // resultsDoneGroup
            // 
            this.resultsDoneGroup.Controls.Add(this.doneLabel);
            this.resultsDoneGroup.Controls.Add(this.excelFileLink);
            this.resultsDoneGroup.Location = new System.Drawing.Point(19, 266);
            this.resultsDoneGroup.Name = "resultsDoneGroup";
            this.resultsDoneGroup.Size = new System.Drawing.Size(630, 37);
            this.resultsDoneGroup.TabIndex = 4;
            // 
            // workingLabel
            // 
            this.workingLabel.AutoSize = true;
            this.workingLabel.Location = new System.Drawing.Point(195, 240);
            this.workingLabel.Name = "workingLabel";
            this.workingLabel.Size = new System.Drawing.Size(273, 13);
            this.workingLabel.TabIndex = 5;
            this.workingLabel.Text = "Working ... this may take a while for a large set of folders on a network drive";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(663, 311);
            this.Controls.Add(this.workingLabel);
            this.Controls.Add(this.resultsDoneGroup);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Records Recording";
            ((System.ComponentModel.ISupportInitialize)(this.depthLevelsToDisplay)).EndInit();
            this.panel1.ResumeLayout(false);
            this.badResultsPanel.ResumeLayout(false);
            this.levelDisplayGroup.ResumeLayout(false);
            this.levelDisplayGroup.PerformLayout();
            this.resultsDoneGroup.ResumeLayout(false);
            this.resultsDoneGroup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label doneLabel;
        private System.Windows.Forms.LinkLabel excelFileLink;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button createExcel;
        private System.Windows.Forms.Label selectLevelText;
        private System.Windows.Forms.Label depthLevelText;
        private System.Windows.Forms.NumericUpDown depthLevelsToDisplay;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel resultsDoneGroup;
        private System.Windows.Forms.Panel levelDisplayGroup;
        private System.Windows.Forms.Label workingLabel;
        private System.Windows.Forms.Panel badResultsPanel;
        private System.Windows.Forms.Label badResultsLabel;
    }
}

