﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace PresentSubfolders
{
    public partial class Form1 : Form
    {
        List<string> allDirectories;
        string searchString;
        SubFolder centralFiles;
        bool currentSubFolderDone;
        bool topLevelFoldersDone;

        //centralFiles is the subFolder that will contain everything
        int slashCorrection; // this allows the subfolders to record their depth by looking at their relation to whatever folder is
                             //used as base folder for collecting subfolder information

        public Form1()
        {
            InitializeComponent();
            badResultsPanel.Visible = false;
            workingLabel.Visible = false;
            levelDisplayGroup.Visible = false;
            resultsDoneGroup.Visible = false;
        }

        /// <summary>
        /// Kicks of the search for subfolders. It relies on populateSubFolders() to do most of the work.
        /// </summary>
        private void startSearch()
        {
            badResultsPanel.Visible = false;
            currentSubFolderDone = false;
            topLevelFoldersDone = false;
            workingLabel.Visible = true;
            workingLabel.Update();
            if(levelDisplayGroup.Visible)
            {
                levelDisplayGroup.Visible = false;
                //reset the text about the depth level
                depthLevelText.Text = "The folders found went to a depth of";
            }
            if (resultsDoneGroup.Visible)
            {
                resultsDoneGroup.Visible = false;
            }
            Program.maxLevel = 0;
            string currentFolderName;
            int slashPosition;
            SubFolder currentFolder;
            allDirectories = new List<string>();
            string[] rootSubdirectoryEntries = Directory.GetDirectories(searchString, "*", SearchOption.TopDirectoryOnly);
            slashCorrection = searchString.Count(s => s == '\\');
            if (slashCorrection == 1)
            {//if you're in the top level of a drive, there is no need to correct
                slashCorrection = 0;
            }
            //pull back just the top level
            centralFiles = new SubFolder("T", 1, "");
            //now pull back all top-level subfolders in the ones you've already retrieved
            int i = 0;
            for (i = 0; i < rootSubdirectoryEntries.Length; i++)
            //possibly add progress bar here
            {
                if (rootSubdirectoryEntries[i].IndexOf("Admin") < 0 &&
                    rootSubdirectoryEntries[i].IndexOf("Back up (Restored)") < 0
                    && rootSubdirectoryEntries[i].IndexOf("bu of electronic filing") < 0)
                //don't bother with these directories
                {
                    slashPosition = rootSubdirectoryEntries[i].LastIndexOf("\\");
                    currentFolderName = rootSubdirectoryEntries[i].Substring(slashPosition + 1);
                    if (currentFolderName.IndexOf(",") != -1)
                    {
                        currentFolderName.Replace(",", "','");
                    }
                    currentFolder = centralFiles.createDeeperFolder(currentFolderName, 1, "");
                    //since you're just working in top level folders,
                    //call populateSubFolders for each top level folder; that function will 
                    //record all the subfolders in the top level folder
                    populateSubFolders(currentFolder, rootSubdirectoryEntries[i]);
                }
            }
            if (i == rootSubdirectoryEntries.Length && currentSubFolderDone)
            {
                topLevelFoldersDone = true;
            }

            workingLabel.Visible = false;
            workingLabel.Update();
            //display a max depth, 
            if (topLevelFoldersDone)
            {
                //prompt user to select a depth to display to
                badResultsPanel.Visible = false;
                depthLevelText.Text = depthLevelText.Text + " " + Program.maxLevel.ToString();
                depthLevelsToDisplay.Maximum = Program.maxLevel;
                levelDisplayGroup.Visible = true;
            }
            else
            {
                levelDisplayGroup.Visible = false;
                badResultsPanel.Visible = true;
            }
        }

        /// <summary>
        /// This function will find the sub-folders of inputFolder and put them into inputFolder's subFolders property.
        /// This is a recursive function: if inputFolder itself has subfolders, each of those subFolders will 
        /// be passed, in turn, to this function so that their own subFolders can be detected and attached to them.
        /// E.g., first subFolder is called Folder1; it has 3 subfolders, Level21, Level22, and Level23. Level21 has two subfolders:
        /// Level31 and Level32.
        /// Folder1 will be passed to this function. Before execution is complete, Level21 will be passed to this function, then 
        /// Level31 and Level32 will be passed to it. Once the function has completed working on Level31 and Level32, it will 
        /// complete work on Level21. It will then complete work on Level22 and Level23 and finally complete on Folder1. By that time,
        /// all of Level21, Level22 and Level23 will be noted as subfolders of Folder1. Level21 (itself inside Folder1)
        /// will contain Level31 and Level32.
        /// </summary>
        /// <param name="inputFolder">This is subfolder object</param>
        /// <param name="path">This is the full file path corresponding to the subfolder object</param>
        public void populateSubFolders(SubFolder inputFolder, string path)
        {
            if (path.IndexOf("bu of electronic filing") < 0 &&
                path.IndexOf("Not for Circulation") < 0)
            {
                int numberOfSubFolders = 0;
                string[] subFolders;
                SubFolder newFolder;
                int slashPosition;
                string currentFolderName;
                string parentFolderName;
                int currentFolderDepth;
                try
                {
                    subFolders = Directory.GetDirectories(path, "*", SearchOption.TopDirectoryOnly);
                    numberOfSubFolders = subFolders.Length;
                    int i = 0;
                    if (numberOfSubFolders > 0)
                    {
                        for (i = 0; i < numberOfSubFolders; i++)
                        {
                            slashPosition = subFolders[i].LastIndexOf("\\");
                            currentFolderName = subFolders[i].Substring(slashPosition + 1);
                            if (currentFolderName.IndexOf(",") != -1)
                            {
                                currentFolderName.Replace(",", "','");
                            }
                            //for folder "T:\\BU - BUDGET AND FALL ECONOMIC STATEMENTS\\2021\\01 - Binder & Lock Up"
                            //depth is 3
                            currentFolderDepth = subFolders[i].Count(s => s == '\\');
                            currentFolderDepth = currentFolderDepth - slashCorrection;
                            parentFolderName = subFolders[i].Substring(0, slashPosition);
                            slashPosition = parentFolderName.LastIndexOf("\\");
                            parentFolderName = parentFolderName.Substring(slashPosition + 1);
                            newFolder = inputFolder.createDeeperFolder(currentFolderName, currentFolderDepth, parentFolderName);
                            populateSubFolders(newFolder, subFolders[i]);
                        }
                    }
                    if (i == numberOfSubFolders)
                    {
                        currentSubFolderDone = true;
                    }
                }
                catch (System.Exception e)
                {
                    currentSubFolderDone = false;
                    /*
                    string message = "Error in collecting folder names. Clock OK and try again. If the problem persists," +
                        "please tell Mitch.";
                    message += "  System error message: " + e.ToString();
                    string caption = "Error collecting folder names";
                    MessageBoxButtons btns = MessageBoxButtons.OK;
                    DialogResult userResponse = MessageBox.Show(message, caption, btns);
                    if (userResponse == System.Windows.Forms.DialogResult.OK)
                    {
                        return;
                    }
                    */

                    /*
                     * sample error :
                     * System.IO.DirectoryNotFoundException
  HResult=0x80070003
  Message=Could not find a part of the path 'T:\MD - MODELLING AND DATA\01 - Provdata and Models\
                    01 - General Series\01 - General\Benefit Calculator\Old versions 2012 Benefit Calculator\2011 Benefit Calculator base case for OCB disabled single parent\Benefit Calculator 2011\themes\pepper-grinder\images'.
                     * 
                     */
                }
            }
        }

        /// <summary>
        /// This function does the work of writing the information about each individual subfolder. That information
        /// is kept in the string that will form the CSV.
        /// This is a recursive function, so if a subfolder that is passed to this function itself has next-level subfolders, 
        /// this function will call itself, passing in those next-level subfolders.
        /// </summary>
        /// <param name="sfIn">subfolder whose information is to be written to the csv</param>
        /// <param name="csvIn">The csv string (passed by reference)</param>
        private void recordSubFoldersInCSVString(SubFolder sfIn, ref StringBuilder csvIn)
        {
            string lineComposer;
            for (int i = 0; i < sfIn.subFolders.Count; i++)
            {//record the items at the top level of the queue of subfolders that was passed in
                if (sfIn.subFolders.ElementAt(i).sfLevel <= depthLevelsToDisplay.Value)
                {//only record the folder if it's within the levels to be displayed
                    //add commmas to reflect depth level of the subfolder; these will turn into columns when CSV is converted to excel.
                    lineComposer = new String(',', sfIn.subFolders.ElementAt(i).sfLevel - 1);
                    lineComposer += sfIn.subFolders.ElementAt(i).sfName;
                    csvIn.AppendLine(lineComposer);
                    if (sfIn.subFolders.ElementAt(i).subFolders.Count > 0)
                    {//if there are more subFolders within this one, record all of them
                        recordSubFoldersInCSVString(sfIn.subFolders.ElementAt(i), ref csvIn);
                    }
                }
            }
        }

        /// <summary>
        /// This is the main function to control output to an excel file.
        /// Each subfolder that exists gets passed to recordSubFolders(), which creates a record, in the string that 
        /// will form the CSV, for that individual subFolder.
        /// 
        /// /// </summary>
        public void recordResultsToExcel()
        {            //output results to a file
            Excel.Application oXL;
            Workbook wb;
            Worksheet ws;
            Excel.Range oRng;
            oXL = new Microsoft.Office.Interop.Excel.Application();
            wb = oXL.Workbooks.Add(System.Reflection.Missing.Value);
            try
            {
                var csv = new StringBuilder();
                string row;
                //populate this whole thing
                for (int i = 0; i < centralFiles.subFolders.Count; i++)
                {
                    //this is just the top level of subfolders
                    //record the top level subfolder
                    row = centralFiles.subFolders.ElementAt(i).sfName;
                    csv.AppendLine(row);
                    if (centralFiles.subFolders.ElementAt(i).subFolders.Count > 0)
                    {//this subfolder has subfolders of its own, so go record them
                        recordSubFoldersInCSVString(centralFiles.subFolders.ElementAt(i), ref csv);
                    }
                }
                System.Windows.Forms.SaveFileDialog sa = new System.Windows.Forms.SaveFileDialog();
                sa.InitialDirectory = @"C:\";
                sa.Title = "Where to save the folder list";
                sa.DefaultExt = "xlsx";
                sa.Filter = "Excel Files(.xlsx)|*.xlsx";
                sa.RestoreDirectory = true;
                if (sa.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    //save as CSV, then open that in excel.
                    string fileName = sa.FileName + ".csv";
                    File.WriteAllText(fileName, csv.ToString());
                    //open in excel, format, and save as excel file
                    wb = oXL.Workbooks.Open(fileName);
                    ws = wb.Worksheets[1];
                    ws.Columns.ColumnWidth = 2;
                    ws.Range["A1:B1"].EntireColumn.Font.Size = 12;
                    ws.Range["A1:B1"].EntireColumn.ColumnWidth = 1.5;
                    oRng = ws.Columns[1];
                    oRng.EntireColumn.Font.Bold = true;
                    oRng = ws.Columns[2];
                    oRng.EntireColumn.Font.Underline = true;
                    fileName = fileName.Replace(".csv", "");
                    wb.SaveAs(fileName, XlFileFormat.xlOpenXMLWorkbook,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlExclusive,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    //get rid of the csv file
                    File.Delete(fileName + ".csv");
                    //doneLabel.Visible = true;
                    excelFileLink.Text = fileName;
                    //excelFileLink.Visible = true;
                    resultsDoneGroup.Visible = true;
                    excelFileLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);

                }
            }
            catch (Exception e)
            {
                //error in the attempt to write excel file
                string message = "Error writing to excel. Clock OK and try again. If the problem persists," +
                    "please tell Mitch.";
                message += "  System error message: " + e.ToString();
                string caption = "Excel writing error";
                MessageBoxButtons btns = MessageBoxButtons.OK;
                DialogResult userResponse = MessageBox.Show(message, caption, btns);
                if (userResponse == System.Windows.Forms.DialogResult.OK)
                {
                    //!!!maybe you need to throw an error here to report to any calling function
                    return;
                }
            }
            finally
            {
                wb.Close();
                oXL.Quit();
            }
        }

        /// <summary>
        /// Allows user to select the root folder from which they start recording subfolders.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SelectFolders(object sender, EventArgs e)
        {
            excelFileLink.Text = "";
            OpenFileDialog folderBrowser = new OpenFileDialog();
            // Set validate names and check file exists to false otherwise windows will
            // not let you select "Folder Selection."
            folderBrowser.ValidateNames = false;
            folderBrowser.CheckFileExists = false;
            folderBrowser.CheckPathExists = true;
            // Always default to Folder Selection.
            folderBrowser.FileName = "Folder Selection.";
            if (folderBrowser.ShowDialog() == DialogResult.OK)
            {
                searchString = Path.GetDirectoryName(folderBrowser.FileName);
                startSearch();
            }
        }

        /// <summary>
        /// Event handler for clicking on the link to the created excel file.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void linkLabel1_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(((System.Windows.Forms.LinkLabel)sender).Text);
        }

        private void depthLevelsToDisplay_ValueChanged(object sender, EventArgs e)
        {

        }

        private void createExcel_Click(object sender, EventArgs e)
        {
            if (resultsDoneGroup.Visible)
            {
                resultsDoneGroup.Visible = false;
            }
            recordResultsToExcel();
        }

        private void badResultsLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
